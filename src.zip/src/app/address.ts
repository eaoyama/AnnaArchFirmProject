export class Address1 {

    constructor(
        public c_id: number,
        public address1: string,
        public address2: string,
        public city: string,
        public state: string,
        public zip: string,
        public address_notes: string,
        public a_id: number
        
    ){}

}

export class Address2 {

    constructor(
        public c_id: number,
        public address1: string,
        public address2: string,
        public city: string,
        public state: string,
        public zip: string,
        public address_notes: string,
        public a_id: number
        
    ){}

}

export class Address3 {

    constructor(
        public c_id: number,
        public address1: string,
        public address2: string,
        public city: string,
        public state: string,
        public zip: string,
        public address_notes: string,
        public a_id: number
        
    ){}

}