export class Client {

    constructor(
        public c_id: number,
        public f_name: string,
        public m_name: string,
        public l_name: string,
        public email: string,
        public phone: string,
        public profile_notes: string
    ){}


}