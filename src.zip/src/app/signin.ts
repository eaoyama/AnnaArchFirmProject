export class Signin {

    constructor(
        public username: string,
        public password: string,
    ) {}

}